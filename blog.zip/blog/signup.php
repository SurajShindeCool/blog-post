<?php
session_start();
$db = mysqli_connect("localhost", "root", "", "blogsignup");
if(isset($_POST['btn'])){
	$username = $_POST['name'];
	$email = $_POST['email'];
	$password = $_POST['pass'];
	$password2 = $_POST['pass2'];

	if ($password == $password2){
		$password = md5($password);
		$sql = "INSERT INTO signup(name, email, pass)VALUES('$username', '$email', '$password')";
		mysqli_query($db, $sql);
		$_SESSION['message'] = "You are now logged in";
		$_SESSION['username'] = $username;
		header("location: index.php");
	}else{
		$_SESSION['message'] = "The two passwords do not match";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	 <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
	<div class="container">
		<h1>Sign Up</h1>
		<form method="post" action="">
			<table>
				<tr><td>Name:</td><td><input type="text" name="name" placeholder="Enter Your Name"></td></tr>
				<tr><td>Email Id:</td><td><input type="text" name="email" placeholder="Enter Your Email"></td></tr>
				<tr><td>Password:</td><td><input type="password" name="pass" placeholder="Enter Password"></td></tr>
				<tr><td>Confirm Password:</td><td><input type="password" name="pass2" placeholder="Confirm Password"></td></tr>
				<tr><td><input type="submit" name="btn" value="register"></td></tr>
			</table>
		</form>
	</div>
</body>
</html>
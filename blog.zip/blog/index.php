<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
    <script type="text/javascript">
    function myFunction(id){
        var divelement = document.getElementById(id);

        if(divelement.style.display == 'none')

            divelement.style.display = 'block';
            else
            divelement.style.display = 'none';
    }
    </script>
</head>
<body>
    <section id="main_box">
        <section class="container">
            <header>
                <h5>Subscribe</h5>
                <h4>Large</h4>
                <div class="form">
                    <a href="signup.php" target="_blank"><button>Sign Up</button></a>
                    <h6>Welcome <?php echo $_SESSION['username'] ?></h6>
                </div>
            </header>
            <a href="javascript:void(0);" class="icon" onclick="myFunction('sectinHide')" id="nav">
                <i class="fa fa-bars"></i>
        </a>
            <div class="buttons" id="sectinHide">
                <button>World</button>
                <button>U.S</button>
                <button>Technology</button>
                <button>Design</button>
                <button>Culture</button>
                <button>Business</button>
                <button>Politics</button>
                <button>Opinion</button>
                <button>Science</button>
                <button>Health</button>
                <button>Style</button>
                <button>Travel</button>
            </div>
            <div class="box">
                <h1>Title Of Longer <br>Feauture blog post</h1>
                <p>It is a long established fact that a reader <br>will be distracted by the readable content of a page<br> when looking at its layout.</p>
                <h3>Continue Loading...</h3>
            </div>
            <div class="dual">
                <div class="dual_1">
                    <div class="dual_1l">
                        <h2>World</h2>
                        <h2>Feautured Post</h2>
                        <h5>Nov 12</h5>
                        <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                        <h4>Continue Reading</h4>
                    </div>
                    <div class="side_1">
                        <h4>Thumbnail</h4>
                    </div>
                </div>
                <div class="dual_2">
                    <div class="dual_2l">
                        <h2>World</h2>
                        <h2>Feautured Post</h2>
                        <h5>Nov 12</h5>
                        <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                        <h4>Continue Reading</h4>
                    </div>
                    <div class="side_2">
                        <h4>Thumbnail</h4>
                    </div>
                </div>
            </div>
            <div class="left">
                    <h1>From The Firehose</h1>
                    <hr>
                    <div class="first">
                        <h2>Sample Blog First</h2>
                        <p>January 1, 2014 by Mark</p>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.<br></p>
                        <hr>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <h2>Heading</h2>
                        <p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <h2>Sub-Heading</h2>
                        <p>If you are going to use a passage of Lorem Ipsum.</p>
                        <p> you need to be sure </p>
                        <p>there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <h2>Heading</h2>
                        <p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <ul>
                            <li>Randomised words which don't look even slightly believable.</li>
                            <li>Randomised words which don't look even slightly believable.</li>
                            <li>Randomised words which don't look even slightly believable.</li>
                        </ul>
                        <p>there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.</p>
                        <ol type="number">
                            <li>Randomised words which don't look even slightly believable.</li>
                            <li>Randomised words which don't look even slightly believable.</li>
                            <li>Randomised words which don't look even slightly believable.</li>
                        </ol>
                        <h2>Another Blog Post</h2>
                        <p>January 1, 2014 by Mark</p>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.<br></p>
                        <hr>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <h2>New Feauture</h2>
                        <p>January 1, 2014 by Mark</p>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.<br></p>
                        <hr>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                        <p> If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                    </div>
                    <button class="old">Older</button>
                    <button class="new">Newer</button>
                </div>
                <div class="right">
                    <div class="top">
                        <i><h3>About</h3></i>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                    </div>
                    <ul>
                        <i><h3>Archives</h3></i>
                        <a href=""><li>March 2014</li></a>
                        <a href=""><li>February 2014</li></a>
                        <a href=""><li>January 2013</li></a>
                        <a href=""><li>December 2013</li></a>
                        <a href=""><li>November 2013</li></a>
                        <a href=""><li>October 2013</li></a>
                        <a href=""><li>September 2013</li></a>
                        <a href=""><li>August 2013</li></a>
                        <a href=""><li>July 2013</li></a>
                        <a href=""><li>June 2013</li></a>
                        <a href=""><li>May 2013</li></a>
                        <a href=""><li>April 2013</li></a>
                    </ul>
    
                    <ul>
                            <i><h3>Elsewhere</h3></i>
                            <a href=""><li>March 2014</li></a>
                            <a href=""><li>February 2014</li></a>
                            <a href=""><li>January 2013</li></a>
                        </ul>
                </div>
        </section>
        
    </section>



</body>
</html>